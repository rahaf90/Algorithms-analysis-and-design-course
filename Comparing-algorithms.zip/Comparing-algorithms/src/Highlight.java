

import java.awt.Color;
import javax.swing.text.DefaultHighlighter;

public class Highlight extends DefaultHighlighter.DefaultHighlightPainter {

    public Highlight(Color c) {
        super(c);
    }

}
